# Marshall Triangle Visualization Application

Proof-of-concept application demonstrating the Marshall Triangle rendering engine using Python and Streamlit.

**Status:** Internal Prototype / Research

**Core Logic:** `harmony_index.py`
**UI:** `app.py` (Streamlit)

**License:** See LICENSE file (All Rights Reserved).
