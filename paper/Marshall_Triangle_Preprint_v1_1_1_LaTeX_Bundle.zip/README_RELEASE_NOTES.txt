Marshall Triangle Preprint v1.1.1 LaTeX Bundle

This bundle contains the revised MDPI/Preprints-style LaTeX source, figure assets, and Definitions files used to compile Marshall_Triangle_Preprint_v1_1_1.pdf.

Version notes:
- Adds a Related Work and Conceptual Context section.
- Adds external scholarly references, including Maxwell (1860), CIE 1931/1932, Smith and Guild (1931), visualization, barycentric geometry, multi-objective optimization, and radial basis references.
- Strengthens the mathematical formulation with a normalized state vector, reference Harmony Index, Euclidean metric on the triangular domain, tunable sigma definition, and hue-preserving normalization operator.
- Moves project URLs and provenance links into Data Availability rather than the bibliography.
- Shortens the AI-assisted tools acknowledgment.
- Softens conflict-of-interest language.
- Leaves Zenodo DOI marked as forthcoming pending public archive release.
