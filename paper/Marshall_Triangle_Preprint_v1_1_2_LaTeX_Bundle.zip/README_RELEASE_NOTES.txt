Marshall Triangle Preprint v1.1.2 LaTeX Bundle

This bundle contains the revised MDPI/Preprints-style LaTeX source, figure assets, and Definitions files used to compile Marshall_Triangle_Preprint_v1_1_2.pdf.

Version notes (v1.1.2):
- Switches the canonical Zenodo DOI to the all-versions handle: https://doi.org/10.5281/zenodo.20696528
- No content changes relative to v1.1.1; this release archives the all-versions DOI reference.